#include <stdio.h>
#include <stdlib.h>

typedef int TipoChave;
typedef int TipoValor;

struct TipoListaEncadeada{

	TipoChave chave;
	TipoValor valorQualquer;
	struct TipoListaEncadeada *prox;
	struct TipoListaEncadeada *ant;

};

typedef struct TipoListaEncadeada TipoListaEncadeada;

void printa(TipoListaEncadeada **prim){

	if(*prim == NULL) return ;
	
	printf("%d  %d\n",(*prim)->chave, (*prim)->valorQualquer);
	
	if((*prim)->prox == NULL) return ;
	printa(&(*prim)->prox);

}


TipoListaEncadeada *insereInicioListaEncadeada(TipoListaEncadeada **prim, TipoChave chave, TipoValor valor){

	if(*prim == NULL){
	
		*prim = malloc(sizeof(TipoListaEncadeada));
		if(*prim == NULL) return NULL;
		
		(*prim)->chave = chave;
		(*prim)->valorQualquer = valor;
		(*prim)->prox = NULL;
		(*prim)->ant = NULL;
		return *prim;
		
	}
	
	TipoListaEncadeada *aux=malloc(sizeof(TipoListaEncadeada));
	if(aux == NULL) return NULL;
	
	(*prim)->ant = aux;
	aux->prox = (*prim);
	aux->ant = NULL;
	aux->chave = chave;
	aux->valorQualquer = valor;
	return aux;
 
}

TipoListaEncadeada *insereFimListaEncadeada(TipoListaEncadeada**prim, TipoChave chave, TipoValor valor){

	if(*prim == NULL){
	
		*prim = insereInicioListaEncadeada(prim,chave,valor);
		return *prim;
	
	}
	
	TipoListaEncadeada *aux = *prim, *aux2 = malloc(sizeof(TipoListaEncadeada));
	if(aux2 == NULL) return NULL;
	
	while(aux->prox != NULL) aux = aux->prox;
	
	aux->prox = aux2;
	aux2->ant = aux;
	aux2->prox = NULL;
	aux2->chave = chave;
	aux2->valorQualquer = valor;
	return aux2;

}

void removeNo(TipoListaEncadeada **prim, TipoChave chave){

	if(*prim == NULL){
		puts("Lista vazia");
		return ;
	}
	
	if((*prim)->prox == NULL && (*prim)->ant == NULL && (*prim)->chave == chave){
		
		free(*prim);
		*prim = NULL;
		return ;
	}
	
	TipoListaEncadeada *aux = *prim;
	
	while(1){
	
		if(aux->chave == chave){
		
			 
			
		
			if(aux->ant == NULL){
			
				(*prim) = aux->prox;
				aux->prox->ant = NULL;
				aux->prox = NULL;
				free(aux);
				return ;
			
			}
			
			if(aux->prox == NULL){
			
				aux->ant->prox = NULL;
				aux->ant = NULL;
				free(aux);
				
				return ;
			
			}
		
			aux->ant->prox = aux->prox;
			aux->prox->ant = aux->ant;
			free(aux);
			aux->prox = NULL;
			aux->ant = NULL;
			
			return ;
		
		}
		
		if(aux->prox == NULL) return ;
		aux = aux->prox;
	
	}

}

TipoListaEncadeada *copiaLista3(TipoListaEncadeada *prim){

	if(prim == NULL){

		puts("Lista n criada");
		return NULL;
	}

	TipoListaEncadeada *aux = prim, *cpy=NULL;
	
	while(aux->prox != NULL){
	
		if(aux->chave%3 == 0) cpy=insereInicioListaEncadeada(&cpy,aux->chave,aux->valorQualquer);
	
		aux = aux->prox;
	
	}
	
	if(aux->chave%3 == 0) cpy=insereInicioListaEncadeada(&cpy,aux->chave,aux->valorQualquer);

	return cpy;
}

