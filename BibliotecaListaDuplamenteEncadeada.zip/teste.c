#include <stdio.h>
#include <stdlib.h>
#include "bib.h"

int main(){
	
	TipoListaEncadeada *prim = NULL,*last = NULL,*cpy=NULL;
	int chave,valor,n;
	
	while(1){
	
		puts("1-InsereInicio 2-InsereFim 3-RemoveNo 4-Copia3 0-nd");
		scanf("%d",&n);
		if(n == 0) break;
		
		switch(n){
		
			case 1:scanf("%d %d",&chave,&valor);prim = insereInicioListaEncadeada(&prim,chave,valor);puts("Lista");printa(&prim);break;
			case 2:scanf("%d %d",&chave,&valor);last = insereFimListaEncadeada(&prim,chave,valor);puts("Lista");printa(&prim);break;
			case 3:scanf("%d",&chave);removeNo(&prim,chave);puts("Lista");printa(&prim);break;
			case 4:cpy = copiaLista3(prim);puts("Lista");printa(&prim);puts("Copia");printa(&cpy);break;
		
		}
	}
}
