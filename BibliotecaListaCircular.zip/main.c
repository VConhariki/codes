#include <stdio.h>
#include <stdlib.h>

typedef int TipoChave;
typedef int TipoValor;

struct TipoListaCircular{
	TipoChave chave;
	TipoValor valorQualquer;
	struct TipoListaCircular *prox;
};

typedef struct TipoListaCircular TipoListaCircular;


void printa(TipoListaCircular **l){

	if(*l == NULL){
		puts("Lista vazia");
		return ;
	}
	
	TipoListaCircular *aux = *l;
		
	while(aux->prox != *l){
	
		printf("%d\n",aux->prox->chave);
		aux = aux->prox;
	}
	printf("%d\n",aux->prox->chave);
	return ;

}


TipoListaCircular *insereInicioListaCircular(TipoListaCircular **prim, TipoChave chave, TipoValor valor){

	if(*prim == NULL){
		
		*prim = malloc(sizeof(TipoListaCircular));
		if(*prim == NULL) return NULL;
		
		(*prim)->chave = chave;
		(*prim)->valorQualquer = valor;
		(*prim)->prox = *prim;
		return *prim;
	}else{
	
		TipoListaCircular *aux = malloc(sizeof(TipoListaCircular));
		if(aux == NULL) return NULL;
		
		aux->chave = chave;
		aux->valorQualquer = valor;
		aux->prox = (*prim)->prox;
		(*prim)->prox = aux;
		return aux;
	
	}
	
}

void removeNo(TipoListaCircular **prim, TipoChave chave){

	if(*prim == NULL) return ;
	
	if((*prim)->prox == *prim){
	
		free(*prim);
		*prim = NULL;
		return ;
	}
	
	TipoListaCircular *aux = (*prim);
	
	do{
		if(aux->prox->chave == chave){
	
			TipoListaCircular *aux2 = aux->prox;
		
			aux->prox = aux2->prox;
			free(aux2);
			aux2->prox = NULL;
			return ;
	
		}
		
		aux = aux->prox;
		
	}while(aux->prox != *prim);
	
	if(aux->prox->chave == chave){
		
		TipoListaCircular *aux2 = aux->prox;
		
		aux->prox = aux2->prox;
		free(aux2);
		aux2->prox = NULL;
		*prim = aux;
		return ;
	
	}
	
	puts("Chave n encontrada");
	return ;

}

TipoListaCircular *copiaListaPar(TipoListaCircular *prim){

	if(prim == NULL) return NULL;
	
	TipoListaCircular *aux = prim,* aux2 = NULL;
	
	do{
		if(aux->prox->chave%2 == 0) insereInicioListaCircular(&aux2,aux->prox->chave,aux->prox->valorQualquer);
		
		aux = aux->prox;
		
	}while(aux->prox != prim);
	
	if(aux->prox->chave%2 == 0) insereInicioListaCircular(&aux2,aux->prox->chave,aux->prox->valorQualquer);
	
	return aux2;

}


int main(){

	TipoListaCircular *l=NULL,*prim=NULL,*cpy=NULL;
	int chave,valor,n;
	
	while(1){
	
		puts("Digite:");
		puts("1-insere inicio  2-removeNo  3-CopiaPar -1-nd");
		scanf(" %d", &n);
		if(n<0) break;
		switch(n){
			
			case 1: scanf(" %d", &chave); scanf(" %d", &valor);insereInicioListaCircular(&l,chave,valor); printa(&l);break;
			case 2: scanf(" %d", &chave); removeNo(&l,chave); printa(&l);break;
			case 3: cpy = copiaListaPar(l); puts("Lista:");printa(&l);puts("Copia:");printa(&cpy);break;
		
		}
	
	
	
	}
	
}
