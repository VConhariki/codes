#include <stdio.h>
#include <stdlib.h>
#include "bib.h"

int main(){

	TipoListaCircular *l=NULL,*prim=NULL,*cpy=NULL;
	int chave,valor,n;
	
	while(1){
	
		puts("Digite:");
		puts("1-insere inicio  2-removeNo  3-CopiaPar -1-nd");
		scanf(" %d", &n);
		if(n<0) break;
		switch(n){
			
			case 1: scanf(" %d", &chave); scanf(" %d", &valor);insereInicioListaCircular(&l,chave,valor); printa(&l);break;
			case 2: scanf(" %d", &chave); removeNo(&l,chave); printa(&l);break;
			case 3: cpy = copiaListaPar(l); puts("Lista:");printa(&l);puts("Copia:");printa(&cpy);break;
		
		}
	
	
	
	}
	
}
