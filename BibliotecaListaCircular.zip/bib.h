typedef int TipoChave;
typedef int TipoValor;

struct TipoListaCircular{
	TipoChave chave;
	TipoValor valorQualquer;
	struct TipoListaCircular *prox;
};

typedef struct TipoListaCircular TipoListaCircular;

void printa(TipoListaCircular ** );

TipoListaCircular *insereInicioListaCircular(TipoListaCircular ** , TipoChave , TipoValor );

void removeNo(TipoListaCircular ** , TipoChave );

TipoListaCircular *copiaListaPar(TipoListaCircular *prim);
